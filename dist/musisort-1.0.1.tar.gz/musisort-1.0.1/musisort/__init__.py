"""
musisort.

An example python library.
"""

__version__ = "0.0.1"
__author__ = 'Garrison Vanzin'
__credits__ = 'Allegheny College'

appname = "musisort"
appauthor = "vanzing"