"""
musisort.

An example python library.
"""

__version__ = "1.1.0"
__author__ = 'Garrison Vanzin'
__credits__ = 'Allegheny College'

appname = "musisort"
appauthor = "vanzing"